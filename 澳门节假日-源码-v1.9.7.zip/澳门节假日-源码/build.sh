#!/bin/bash
set -e

SDK=/home/user/toolchain/android-sdk
BT=$SDK/build-tools/34.0.0
PLATFORM=$SDK/platforms/android-34/android.jar
JAVA_HOME=/home/user/toolchain/jdk-17.0.10+7
export PATH=$JAVA_HOME/bin:$PATH

cd "$(dirname "$0")"
OUT=build
rm -rf "$OUT"
mkdir -p "$OUT/compiled" "$OUT/gen" "$OUT/classes" "$OUT/dex"

# 1) 编译资源
"$BT/aapt2" compile --dir res -o "$OUT/compiled/res.zip"

# 2) 链接资源，生成基准 APK 与 R.java
"$BT/aapt2" link \
  -o "$OUT/base.apk" \
  -I "$PLATFORM" \
  --manifest AndroidManifest.xml \
  --min-sdk-version 24 \
  --target-sdk-version 34 \
  --java "$OUT/gen" \
  "$OUT/compiled/res.zip"

# 3) 编译 Java
find src "$OUT/gen" -name "*.java" > "$OUT/sources.txt"
javac -source 8 -target 8 -encoding UTF-8 \
  -classpath "$PLATFORM" \
  -d "$OUT/classes" \
  @"$OUT/sources.txt" 2>&1 | grep -v "bootstrap class path" || true

# 4) dex
"$BT/d8" --lib "$PLATFORM" --min-api 24 --output "$OUT/dex" \
  $(find "$OUT/classes" -name "*.class")

# 5) 合并 dex 进 APK
cp "$OUT/base.apk" "$OUT/unsigned.apk"
cd "$OUT"
cp dex/classes.dex .
zip -q -u unsigned.apk classes.dex
cd ..

# 6) 对齐
"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"

# 7) 签名（固定证书：项目根 debug.keystore，务必保留，删了签名就变）
KEYSTORE="$PWD/debug.keystore"
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -v -keystore "$KEYSTORE" \
    -storepass android -keypass android -alias androiddebugkey \
    -keyalg RSA -keysize 2048 -validity 10950 \
    -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
fi

"$BT/apksigner" sign \
  --ks "$KEYSTORE" --ks-pass pass:android \
  --key-pass pass:android --ks-key-alias androiddebugkey \
  --out "$OUT/app-debug.apk" "$OUT/aligned.apk"

"$BT/apksigner" verify --print-certs "$OUT/app-debug.apk" | head -5
ls -lh "$OUT/app-debug.apk"
