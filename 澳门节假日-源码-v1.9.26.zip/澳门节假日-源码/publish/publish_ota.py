#!/usr/bin/env python3
"""澳门日历 OTA 发布脚本

用法：
    python3 apkbuild/publish/publish_ota.py <版本号> "<更新说明，\\n 分隔>" [--force]

例：
    python3 apkbuild/publish/publish_ota.py 1.9.26 "1. 修复某问题\n2. 优化某界面"

前置条件（均由构建脚本自动完成，此处只读出信息）：
    - APK：<项目根>/澳门节假日-v<版本>.apk（已用 secrets/release.keystore 签名）
    - 版本号/versionName 从 APK 的 AndroidManifest 读取，避免手写错
    - 私钥：secrets/ota_manifest_private.pem（清单签名）
    - Token：secrets/github_token.txt（GitHub Contents 读写）

做的事：
    1. 计算 APK sha256
    2. 生成 update.json（单文件自包含签名：{"payload":..., "sig":...}）
    3. 上传 dist/app-<版本>.apk（独立文件名，避免 CDN 缓存旧包）、dist/app-latest.apk（镜像）
    4. 上传 dist/update.json
    5. 删除上一版的 dist/app-<旧版本>.apk
"""

import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import urllib.parse
import urllib.request

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

USER = "kimzhoua"
REPO = "macau-calendar-publish"
BRANCH = "main"
RAW = f"https://raw.githubusercontent.com/{USER}/{REPO}/{BRANCH}/dist"

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SECRETS = os.path.join(ROOT, "secrets")
AAPT = "/home/user/toolchain/android-sdk/build-tools/34.0.0/aapt2"


def read_token():
    with open(os.path.join(SECRETS, "github_token.txt"), encoding="utf-8") as f:
        return f.read().strip()


def api_headers(token):
    return {"Authorization": f"token {token}", "Content-Type": "application/json"}


def get_sha(path, token):
    url = (f"https://api.github.com/repos/{USER}/{REPO}/contents/"
           f"{urllib.parse.quote(path)}?ref={BRANCH}")
    req = urllib.request.Request(url, headers=api_headers(token))
    try:
        return json.load(urllib.request.urlopen(req, timeout=60)).get("sha")
    except Exception:
        return None


def put_file(path, content, message, token):
    body = {"message": message,
            "content": base64.b64encode(content).decode(),
            "branch": BRANCH}
    sha = get_sha(path, token)
    if sha:
        body["sha"] = sha
    url = (f"https://api.github.com/repos/{USER}/{REPO}/contents/"
           f"{urllib.parse.quote(path)}")
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 method="PUT", headers=api_headers(token))
    urllib.request.urlopen(req, timeout=180)
    print(f"  上传 {path}")


def delete_file(path, token):
    sha = get_sha(path, token)
    if not sha:
        return
    url = (f"https://api.github.com/repos/{USER}/{REPO}/contents/"
           f"{urllib.parse.quote(path)}")
    body = {"message": "cleanup old release", "sha": sha, "branch": BRANCH}
    req = urllib.request.Request(url, data=json.dumps(body).encode(),
                                 method="DELETE", headers=api_headers(token))
    try:
        urllib.request.urlopen(req, timeout=60)
        print(f"  删除旧文件 {path}")
    except Exception as exc:
        print(f"  删除失败 {path}: {exc}")


def apk_info(apk_path):
    out = subprocess.run([AAPT, "dump", "badging", apk_path],
                         capture_output=True, text=True).stdout
    m = re.search(r"versionCode='(\d+)' versionName='([^']+)'", out)
    if not m:
        raise SystemExit("无法从 APK 读取版本信息")
    return int(m.group(1)), m.group(2)


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) < 2:
        raise SystemExit(__doc__)
    version, notes = args[0], args[1].replace("\\n", "\n")

    apk_path = os.path.join(ROOT, f"澳门节假日-v{version}.apk")
    if not os.path.exists(apk_path):
        raise SystemExit(f"找不到 APK：{apk_path}")

    code, name = apk_info(apk_path)
    apk_bytes = open(apk_path, "rb").read()
    sha = hashlib.sha256(apk_bytes).hexdigest()

    payload = json.dumps({
        "versionCode": code,
        "versionName": name,
        "apkUrl": f"{RAW}/app-{version}.apk",
        "rawApkUrl": f"{RAW}/app-{version}.apk",
        "manifestUrl": f"{RAW}/update.json",
        "sha256": sha,
        "notes": notes,
    }, ensure_ascii=False, indent=2)

    key = serialization.load_pem_private_key(
        open(os.path.join(SECRETS, "ota_manifest_private.pem"), "rb").read(),
        password=None)
    sig = base64.b64encode(
        key.sign(payload.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())
    ).decode()
    wrapper = json.dumps({"payload": payload, "sig": sig},
                         ensure_ascii=False, indent=2).encode("utf-8")

    token = read_token()
    print(f"发布 v{name}（versionCode {code}） sha256={sha[:16]}…")
    put_file(f"dist/app-{version}.apk", apk_bytes, f"Release v{version} apk", token)
    put_file("dist/app-latest.apk", apk_bytes, f"Mirror v{version} apk", token)
    put_file("dist/update.json", wrapper, f"Release v{version} manifest", token)

    src_zip = os.path.join(ROOT, f"澳门节假日-源码-v{version}.zip")
    if os.path.exists(src_zip):
        put_file(f"澳门节假日-源码-v{version}.zip", open(src_zip, "rb").read(),
                 f"Add source v{version}", token)

    # 列出 dist 下所有 app-*.apk，删掉非当前版本的
    url = (f"https://api.github.com/repos/{USER}/{REPO}/contents/"
           f"{urllib.parse.quote('dist')}?ref={BRANCH}")
    req = urllib.request.Request(url, headers=api_headers(token))
    for item in json.load(urllib.request.urlopen(req, timeout=60)):
        p = item["path"]
        if p.startswith("dist/app-") and p.endswith(".apk") and p != f"dist/app-{version}.apk":
            delete_file(p, token)

    print("完成：")
    print(f"  清单 {RAW}/update.json")
    print(f"  安装包 {RAW}/app-{version}.apk")


if __name__ == "__main__":
    main()
