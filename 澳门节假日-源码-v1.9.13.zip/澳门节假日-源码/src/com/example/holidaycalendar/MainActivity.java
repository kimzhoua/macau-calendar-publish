package com.example.holidaycalendar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Environment;
import android.provider.Settings;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;

/**
 * 澳门公众假期日历。
 * 双主题：0 = 简约白（默认），1 = 雅致渐变。数据支持官方 iCal + 年度页面在线更新，内置离线兜底。
 */
public class MainActivity extends Activity {

    private static final String ICS_URL = "https://www.gov.mo/zh-hans/public-holidays/ical/";
    private static final String PAGE_URL = "https://www.gov.mo/zh-hans/public-holidays/year-%d/";

    private static final String CACHE_FILE = "holidays_cache.txt";
    private static final String META_FILE = "holidays_meta.txt";
    private static final String PREF = "prefs";
    /** 应用更新清单地址（可在设置里长按修改；每次发版会换成新地址） */
    private static final String DEFAULT_UPDATE_URL =
            "https://cdn.jsdelivr.net/gh/kimzhoua/macau-calendar-publish@main/dist/update.json";

    private static final String PREF_THEME = "theme_id";
    private static final String PREF_UPDATE_URL = "update_url";
    private static final String PREF_FONT_SCALE = "font_scale";
    private static final String PREF_CARD_BG = "card_bg";
    private static final String PREF_GRID = "grid_on";
    private static final String PREF_LIST_LINE = "list_line";
    private static final String PREF_AL = "al_dates";

    private static final int THEME_SIMPLE = 0;
    private static final int THEME_ELEGANT = 1;
    private static final int THEME_GLASS = 2;

    /** 年月跳转的年份上限（浏览用，不需要官方数据也能翻过去） */
    private static final int MAX_BROWSE_YEAR = 2099;

    /** 联网抓取超出当年的预留年数：官方一般只提前一年公布，多抓两年足够 */
    private static final int FETCH_AHEAD = 2;

    private static final int KIND_HOLIDAY = 0;
    private static final int KIND_HALF = 1;

    private static final String[] WEEK_LABELS = {"日", "一", "二", "三", "四", "五", "六"};

    private static final Pattern TABLE_PAT = Pattern.compile("<table.*?</table>", Pattern.DOTALL);
    private static final Pattern ROW_PAT = Pattern.compile("<tr[^>]*>(.*?)</tr>", Pattern.DOTALL);
    private static final Pattern CELL_PAT = Pattern.compile("<td[^>]*>(.*?)</td>", Pattern.DOTALL);
    private static final Pattern TAG_PAT = Pattern.compile("<[^>]+>");
    private static final Pattern DATE_PAT = Pattern.compile("^(\\d+)月(\\d+)日(（下午）)?");

    private static long lastFetchAt = 0L;
    private long downloadId = -1L;
    /** 更新清单里给出的 SHA-256（可选，给出则下载后校验） */
    private String expectSha256 = null;

    private final BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
            if (id != downloadId) return;
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Uri uri = dm == null ? null : dm.getUriForDownloadedFile(id);
            if (uri == null) {
                Toast.makeText(MainActivity.this, "下载失败，请重试", Toast.LENGTH_SHORT).show();
                return;
            }
            final String expect = expectSha256;
            if (expect == null || expect.length() == 0) {
                installApk(uri);
                return;
            }
            // 清单里给了 sha256 就先校验，避免下载被替换/损坏
            new Thread(new Runnable() {
                @Override
                public void run() {
                    String actual = sha256Of(MainActivity.this, uri);
                    final boolean ok = actual != null && actual.equalsIgnoreCase(expect);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (ok) {
                                installApk(uri);
                            } else {
                                Toast.makeText(MainActivity.this,
                                        "安装包校验失败，已取消安装", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }).start();
        }
    };

    private static class Entry {
        final String name;
        final int kind;
        final String tag;

        Entry(String name, int kind, String tag) {
            this.name = name;
            this.kind = kind;
            this.tag = tag;
        }
    }

    private final Calendar shown = Calendar.getInstance();
    private Map<String, Entry> dataCache;

    private int themeId = THEME_SIMPLE;
    /** 字号倍率 0.8 ~ 1.6，连续可调 */
    private float fontScale = 1.0f;
    /** 是否给日历和本月清单加白色卡片底 */
    private boolean cardBgOn = true;
    /** 日期格子是否显示方框 */
    private boolean gridOn = false;
    /** 公休日列表是否显示行分隔线 */
    private boolean listLineOn = true;
    /** 用户手动标记为 AL（请假）的日期，格式 yyyy-MM-dd */
    private java.util.Set<String> alDates = new java.util.HashSet<>();
    /** 当前点选查看的日期；null 表示显示整月列表 */
    private String selectedDate;
    private TextView sectionTitle;

    private TextView monthTitle;
    private LinearLayout monthList;
    private TextView statusBar;
    private LinearLayout grid;
    private String todayStr;
    private boolean refreshing;
    private HorizontalScrollView pager;
    private LinearLayout pages;
    private int pageWidthPx;
    private final Handler settleHandler = new Handler(Looper.getMainLooper());
    private Runnable settleRunnable;
    private boolean snapping;

    // 主题色
    private int colorBg;
    private int colorTitle;
    private int colorArrow;
    private int colorWeek;
    private int colorHoliday;
    private int colorHalf;
    private int colorWeekend;
    private int colorNormal;
    private int colorAccent;
    private int colorTodayBg;
    private int colorEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.TRANSPARENT);
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);

        SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        // 首次升级到本版时，把默认主题切换为「渐变玻璃」一次
        if (sp.getInt("theme_migrated", 0) == 0) {
            themeId = THEME_GLASS;
            sp.edit().putInt(PREF_THEME, THEME_GLASS).putInt("theme_migrated", 1).apply();
        } else {
            themeId = sp.getInt(PREF_THEME, THEME_GLASS);
        }
        fontScale = sp.getFloat(PREF_FONT_SCALE, 1.0f);
        cardBgOn = sp.getBoolean(PREF_CARD_BG, true);
        gridOn = sp.getBoolean(PREF_GRID, false);
        listLineOn = sp.getBoolean(PREF_LIST_LINE, true);
        alDates = new java.util.HashSet<>(sp.getStringSet(PREF_AL, new java.util.HashSet<String>()));
        applyPalette();

        todayStr = fmt(Calendar.getInstance());

        buildUi();
        loadLocalData();
        refresh();

        // 监听应用包下载完成
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(downloadReceiver, filter);
        }

        // 每天最多自动检查一次新版本
        long lastCheck = getSharedPreferences(PREF, MODE_PRIVATE).getLong("last_update_check", 0L);
        if (System.currentTimeMillis() - lastCheck > 24 * 60 * 60 * 1000L) {
            checkUpdate(false);
        }

        // 10 分钟内不重复自动联网
        if (System.currentTimeMillis() - lastFetchAt > 10 * 60 * 1000L) {
            fetchOnline(false);
        }
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(downloadReceiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    private void applyPalette() {
        if (themeId == THEME_GLASS) {
            colorBg = 0xFFEFF4FC;
            colorTitle = 0xFF1A2233;
            colorArrow = 0xFF26303F;
            colorWeek = 0xFF6B7688;
            colorHoliday = 0xFFE0455E;
            colorHalf = 0xFFE07A2F;
            colorWeekend = 0xFFD5586B;
            colorNormal = 0xFF212836;
            colorAccent = 0xFF5B7BF7;
            colorTodayBg = 0x00000000;
            colorEmpty = 0xFFB3BBC9;
        } else if (themeId == THEME_ELEGANT) {
            colorBg = 0xFFF3F6FB;
            colorTitle = 0xFFFFFFFF;
            colorArrow = 0xFFFFFFFF;
            colorWeek = 0xFFE7F0FF;
            colorHoliday = 0xFFE53935;
            colorHalf = 0xFFF57C00;
            colorWeekend = 0xFFD94A4A;
            colorNormal = 0xFF303640;
            colorAccent = 0xFF1E6FD9;
            colorTodayBg = 0xFFD9E9FF;
            colorEmpty = 0xFFB9C0CC;
        } else {
            colorBg = 0xFFFFFFFF;
            colorTitle = 0xFF1A1A1A;
            colorArrow = 0xFF333333;
            colorWeek = 0xFF333333;
            colorHoliday = 0xFFD32F2F;
            colorHalf = 0xFFEF6C00;
            colorWeekend = 0xFFD32F2F;
            colorNormal = 0xFF222222;
            colorAccent = 0xFF1565C0;
            colorTodayBg = 0xFFE3F2FD;
            colorEmpty = 0xFFB0B0B0;
        }
    }

    private int dp(float v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    // ---------------- 背景工具 --------------

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private GradientDrawable bottomRoundedGradient() {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF1B62C9, 0xFF4AA3F0});
        float r = dp(24);
        d.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        return d;
    }

    // ---------------- UI --------------

    /** 玻璃卡片：半透明白 + 极细高光描边 */
    private GradientDrawable glassCard(float radiusDp, int fill) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), 0x55FFFFFF);
        return d;
    }

    /** 今天的高亮胶囊：蓝紫渐变 */
    private GradientDrawable todayGradient() {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFF7FA8FF, 0xFFB49CFF});
        d.setCornerRadius(dp(12));
        return d;
    }

    /** 玻璃主题背景：柔和渐变 + 三团光斑 */
    private static class BackdropView extends android.view.View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Shader base;
        private Shader blobA;
        private Shader blobB;
        private Shader blobC;

        BackdropView(Context c) {
            super(c);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (w <= 0 || h <= 0) return;
            base = new LinearGradient(0, 0, w, h,
                    new int[]{0xFFE8F1FF, 0xFFF1ECFF, 0xFFFFF0F5},
                    null, Shader.TileMode.CLAMP);
            blobA = new RadialGradient(w * 0.16f, h * 0.10f, w * 0.62f,
                    0x668FB6FF, 0x008FB6FF, Shader.TileMode.CLAMP);
            blobB = new RadialGradient(w * 0.92f, h * 0.30f, w * 0.55f,
                    0x59CBB2FF, 0x00CBB2FF, Shader.TileMode.CLAMP);
            blobC = new RadialGradient(w * 0.50f, h * 0.92f, w * 0.70f,
                    0x40FFC9DE, 0x00FFC9DE, Shader.TileMode.CLAMP);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (base == null) {
                canvas.drawColor(0xFFEFF4FC);
                return;
            }
            paint.setShader(base);
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(blobA);
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(blobB);
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(blobC);
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
        }
    }

    private void buildUi() {
        boolean elegant = themeId == THEME_ELEGANT;
        boolean glass = themeId == THEME_GLASS;

        FrameLayout outer = new FrameLayout(this);
        if (glass) {
            outer.addView(new BackdropView(this), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        if (!glass) root.setBackgroundColor(colorBg);

        // 头部容器
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(12), statusBarHeight() + dp(4), dp(12),
                elegant ? dp(8) : dp(4));
        if (elegant) {
            header.setBackground(bottomRoundedGradient());
        }

        TextView appTitle = new TextView(this);
        appTitle.setText("澳门特别行政区");
        appTitle.setTextSize(glass ? 23 : (elegant ? 21 : 20));
        appTitle.setTypeface(Typeface.DEFAULT_BOLD);
        appTitle.setTextColor(colorTitle);
        appTitle.setGravity(Gravity.CENTER);
        appTitle.setPadding(0, dp(2), 0, dp(glass ? 6 : 3));
        header.addView(appTitle);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);

        TextView prev = icon("‹");
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shown.add(Calendar.MONTH, -1);
                refresh();
            }
        });

        monthTitle = new TextView(this);
        monthTitle.setTextSize(elegant ? 19 : (glass ? 20 : 18));
        monthTitle.setGravity(Gravity.CENTER);
        monthTitle.setTextColor(colorTitle);
        monthTitle.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        monthTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showJumpDialog();
            }
        });
        monthTitle.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                shown.setTimeInMillis(System.currentTimeMillis());
                refresh();
                Toast.makeText(MainActivity.this, "已回到本月", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        TextView settingsBtn = icon("⚙");
        settingsBtn.setTextSize(16);
        settingsBtn.setTextColor(elegant ? 0xFFFFFFFF : colorAccent);
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettingsDialog();
            }
        });

        TextView next = icon("›");
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shown.add(Calendar.MONTH, 1);
                refresh();
            }
        });

        nav.addView(prev);
        nav.addView(monthTitle);
        nav.addView(settingsBtn);
        nav.addView(next);
        header.addView(nav);

        LinearLayout weekHeader = new LinearLayout(this);
        weekHeader.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams whLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        whLp.topMargin = dp(glass ? 4 : (elegant ? 3 : 0));
        weekHeader.setLayoutParams(whLp);
        String[] weekNames = {"一", "二", "三", "四", "五", "六", "日"};
        for (String w : weekNames) {
            TextView tv = new TextView(this);
            tv.setText(w);
            tv.setTextSize(glass ? 14 : 15);
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            tv.setTextColor(colorWeek);
            tv.setGravity(Gravity.CENTER);
            tv.setLayoutParams(new LinearLayout.LayoutParams(0, dp(26), 1));
            weekHeader.addView(tv);
        }
        header.addView(weekHeader);
        root.addView(header);

        // 日历：三页横向翻页容器（上一月 / 本月 / 下一月），手指拖动实时跟随
        pager = new SnapPager(this);
        pager.setHorizontalScrollBarEnabled(false);
        pager.setOverScrollMode(View.OVER_SCROLL_NEVER);
        pager.setFillViewport(false);
        LinearLayout.LayoutParams pagerLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pagerLp.setMargins(dp(elegant ? 12 : (glass ? 12 : 10)),
                dp(glass ? 6 : (elegant ? 8 : 2)),
                dp(elegant ? 12 : (glass ? 12 : 10)), 0);
        if (elegant) {
            if (cardBgOn) {
                pager.setBackground(rounded(0xFFFFFFFF, 18));
                pager.setElevation(dp(6));
            } else {
                pager.setBackground(null);
                pager.setElevation(0);
            }
        } else if (glass) {
            // 玻璃主题默认不铺白色卡片，直接透出渐变背景
            if (cardBgOn) {
                pager.setBackground(glassCard(24, 0xE6FFFFFF));
                pager.setElevation(dp(10));
            } else {
                pager.setBackground(null);
                pager.setElevation(0);
            }
        }
        pager.setLayoutParams(pagerLp);

        pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.HORIZONTAL);
        pages.setPadding(0, dp(4), 0, dp(4));
        pager.addView(pages, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(pager);

        pager.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (settleRunnable != null) settleHandler.removeCallbacks(settleRunnable);
                    // 松手立刻收尾，不等超时
                    pager.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            snapToNearestPage();
                        }
                    }, 16);
                }
                return false;
            }
        });

        // 本月公休日 / 当天详情
        sectionTitle = new TextView(this);
        sectionTitle.setText("本月公休日");
        sectionTitle.setTextSize(14);
        sectionTitle.setTypeface(Typeface.DEFAULT_BOLD);
        sectionTitle.setTextColor(colorAccent);
        sectionTitle.setPadding(dp(glass ? 18 : (elegant ? 14 : 2)), dp(8), dp(2), dp(4));
        root.addView(sectionTitle);

        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        if (elegant) {
            slp.setMargins(dp(12), 0, dp(12), 0);
            if (cardBgOn) {
                scroll.setBackground(rounded(0xFFFFFFFF, 16));
                scroll.setElevation(dp(4));
            } else {
                scroll.setBackground(null);
                scroll.setElevation(0);
            }
        } else if (glass) {
            slp.setMargins(dp(12), 0, dp(12), dp(4));
            if (cardBgOn) {
                scroll.setBackground(glassCard(22, 0xE6FFFFFF));
                scroll.setElevation(dp(10));
            } else {
                scroll.setBackground(null);
                scroll.setElevation(0);
            }
        }
        scroll.setLayoutParams(slp);
        monthList = new LinearLayout(this);
        monthList.setOrientation(LinearLayout.VERTICAL);
        monthList.setPadding(dp(6), dp(6), dp(6), dp(6));
        scroll.addView(monthList);
        root.addView(scroll);

        statusBar = new TextView(this);
        statusBar.setTextSize(10);
        statusBar.setTextColor(glass ? 0xFF7C8698 : (elegant ? 0xFF8A93A3 : 0xFF999999));
        statusBar.setPadding(dp(18), dp(6), dp(14), dp(4));
        statusBar.setText("数据来源：澳门特别行政区政府公众假期表");
        root.addView(statusBar);

        outer.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        applyTypography(root);
        setContentView(outer);
    }

    /** 递归套用字号倍率与字重 */
    private void applyTypography(View v) {
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            if (fontScale != 1.0f) {
                tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, tv.getTextSize() * fontScale);
            }
        } else if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) applyTypography(g.getChildAt(i));
        }
    }

    /** 停手后把日历平滑吸附到最近的一整页，落在邻页就顺势换月 */
    private void scheduleSettle() {
        if (settleRunnable != null) settleHandler.removeCallbacks(settleRunnable);
        settleRunnable = new Runnable() {
            @Override
            public void run() {
                snapToNearestPage();
            }
        };
        settleHandler.postDelayed(settleRunnable, 150);
    }

    private void snapToNearestPage() {
        if (pageWidthPx <= 0 || pager == null || snapping) return;
        // 手指还按着就别吸附，等松手再处理
        if (pager.isPressed()) {
            return;
        }
        // 只要拖动方向明确就翻页，不要求滑过半屏
        int dx = pager.getScrollX() - pageWidthPx;
        int idx;
        if (dx > dp(8)) {
            idx = 2;          // 向左拖 → 下个月
        } else if (dx < -dp(8)) {
            idx = 0;          // 向右拖 → 上个月
        } else {
            idx = 1;          // 基本没动，保持本月
        }
        final int target = idx * pageWidthPx;
        final int delta = idx;  // 0=上一月, 1=本月, 2=下一月

        if (pager.getScrollX() == target) {
            if (delta != 1) commitPage(delta);
            return;
        }

        snapping = true;
        ValueAnimator anim = ValueAnimator.ofInt(pager.getScrollX(), target);
        anim.setDuration(200);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                pager.scrollTo((int) (Integer) a.getAnimatedValue(), 0);
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                snapping = false;
                if (delta != 1) commitPage(delta);
            }
        });
        anim.start();
    }

    /** 真正切换到邻页对应的月份：只轮换三页，不重建当前可见页（避免闪烁） */
    private void commitPage(int pageIndex) {
        if (pageIndex == 1) return;
        int dir = pageIndex == 0 ? -1 : 1;
        shown.add(Calendar.MONTH, dir);
        monthTitle.setText(shown.get(Calendar.YEAR) + "年" + (shown.get(Calendar.MONTH) + 1) + "月");
        buildMonthList();
        rotatePages(dir);
        autoFetchIfMonthEmpty();
    }

    /** 当前显示的这个月完全没有数据时，自动联网补一次（5 分钟内不重复） */
    private void autoFetchIfMonthEmpty() {
        if (refreshing) return;
        if (System.currentTimeMillis() - lastFetchAt < 5 * 60 * 1000L) return;
        String yearPrefix = String.format(Locale.US, "%04d-", shown.get(Calendar.YEAR));
        for (String key : data().keySet()) {
            if (key.startsWith(yearPrefix)) return;
        }
        fetchOnline(false);
    }

    /**
     * 页码右移（dir=+1，切到下月）：丢掉最左页、右侧补一页；
     * 页码左移（dir=-1，切到上月）：丢掉最右页、左侧补一页。
     * 三页宽度各为一屏，位移一页后把 scrollX 归到中间，画面像素不变，因此不会闪。
     */
    private void rotatePages(int dir) {
        if (pages == null || pages.getChildCount() != 3 || pageWidthPx <= 0) return;
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(pageWidthPx,
                ViewGroup.LayoutParams.MATCH_PARENT);
        Calendar base = (Calendar) shown.clone();
        if (dir > 0) {
            pages.removeViewAt(0);
            Calendar m = (Calendar) base.clone();
            m.add(Calendar.MONTH, 1);
            pages.addView(buildMonthPage(m), lp);
        } else {
            pages.removeViewAt(2);
            Calendar m = (Calendar) base.clone();
            m.add(Calendar.MONTH, -1);
            pages.addView(buildMonthPage(m), 0, lp);
        }
        grid = (LinearLayout) pages.getChildAt(1);
        pager.scrollTo(pageWidthPx, 0);
    }

    private TextView icon(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(22);
        tv.setTextColor(colorArrow);
        tv.setGravity(Gravity.CENTER);
        if (themeId == THEME_GLASS) {
            tv.setBackground(rounded(0x4DFFFFFF, 15));
            tv.setLayoutParams(new LinearLayout.LayoutParams(dp(36), dp(36)));
        } else {
            tv.setLayoutParams(new LinearLayout.LayoutParams(dp(34), dp(34)));
        }
        return tv;
    }

    /** 主题选项底座：选中用主题色填充，未选中用浅描边 */
    private void styleThemeChip(TextView chip, boolean active) {
        if (active) {
            chip.setBackground(rounded(colorAccent, 16));
            chip.setTextColor(0xFFFFFFFF);
        } else {
            GradientDrawable d = new GradientDrawable();
            d.setColor(0x14000000);
            d.setCornerRadius(dp(16));
            d.setStroke(dp(1), 0x33000000);
            chip.setBackground(d);
            chip.setTextColor(colorNormal);
        }
    }

    /** 设置面板：主题 + 刷新数据 + 字号/字重连续可调 */
    private void showSettingsDialog() {
        final int[] pendingTheme = {themeId};
        final float[] pendingScale = {fontScale};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(6), dp(20), dp(4));

        final TextView preview = new TextView(this);
        preview.setText("2026年12月  圣诞节");
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(0, dp(6), 0, dp(10));
        preview.setTextColor(colorAccent);
        box.addView(preview);

        TextView themeLabel = new TextView(this);
        themeLabel.setText("主题");
        themeLabel.setTextSize(13);
        themeLabel.setTextColor(0xFF777777);
        box.addView(themeLabel);

        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(0, dp(6), 0, dp(10));
        String[] themeNames = {"简约白", "简约蓝", "渐变玻璃"};
        final TextView[] chipViews = new TextView[themeNames.length];
        for (int i = 0; i < themeNames.length; i++) {
            final int idx = i;
            TextView chip = new TextView(this);
            chip.setText(themeNames[i]);
            chip.setTextSize(13);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(4), dp(9), dp(4), dp(9));
            chip.setMaxLines(1);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            lp.setMargins(dp(2), 0, dp(2), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pendingTheme[0] = idx;
                    for (int k = 0; k < chipViews.length; k++) {
                        styleThemeChip(chipViews[k], k == pendingTheme[0]);
                    }
                }
            });
            chipViews[i] = chip;
            chips.addView(chip);
        }
        box.addView(chips);
        for (int i = 0; i < chipViews.length; i++) {
            styleThemeChip(chipViews[i], i == pendingTheme[0]);
        }

        final TextView sizeLabel = new TextView(this);
        sizeLabel.setTextSize(13);
        sizeLabel.setTextColor(0xFF777777);
        box.addView(sizeLabel);

        final SeekBar sizeBar = new SeekBar(this);
        sizeBar.setMax(100);
        sizeBar.setProgress(Math.round((pendingScale[0] - 0.8f) / 0.8f * 100f));
        box.addView(sizeBar);

        LinearLayout cardRow = new LinearLayout(this);
        cardRow.setOrientation(LinearLayout.HORIZONTAL);
        cardRow.setGravity(Gravity.CENTER_VERTICAL);
        cardRow.setPadding(0, dp(8), 0, dp(2));

        TextView cardLabel = new TextView(this);
        cardLabel.setText("日历添加白底显示");
        cardLabel.setTextSize(13);
        cardLabel.setTextColor(0xFF777777);
        cardLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        cardRow.addView(cardLabel);

        final android.widget.Switch cardSwitch = new android.widget.Switch(this);
        cardSwitch.setChecked(cardBgOn);
        cardSwitch.setPadding(0, 0, 0, 0);
        cardRow.addView(cardSwitch);
        box.addView(cardRow);

        LinearLayout gridRow = new LinearLayout(this);
        gridRow.setOrientation(LinearLayout.HORIZONTAL);
        gridRow.setGravity(Gravity.CENTER_VERTICAL);
        gridRow.setPadding(0, dp(4), 0, dp(2));

        TextView gridLabel = new TextView(this);
        gridLabel.setText("日期显示方框");
        gridLabel.setTextSize(13);
        gridLabel.setTextColor(0xFF777777);
        gridLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        gridRow.addView(gridLabel);

        final android.widget.Switch gridSwitch = new android.widget.Switch(this);
        gridSwitch.setChecked(gridOn);
        gridSwitch.setPadding(0, 0, 0, 0);
        gridRow.addView(gridSwitch);
        box.addView(gridRow);

        LinearLayout lineRow = new LinearLayout(this);
        lineRow.setOrientation(LinearLayout.HORIZONTAL);
        lineRow.setGravity(Gravity.CENTER_VERTICAL);
        lineRow.setPadding(0, dp(4), 0, dp(2));

        TextView lineLabel = new TextView(this);
        lineLabel.setText("公休日列表显示分隔线");
        lineLabel.setTextSize(13);
        lineLabel.setTextColor(0xFF777777);
        lineLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        lineRow.addView(lineLabel);

        final android.widget.Switch lineSwitch = new android.widget.Switch(this);
        lineSwitch.setChecked(listLineOn);
        lineSwitch.setPadding(0, 0, 0, 0);
        lineRow.addView(lineSwitch);
        box.addView(lineRow);

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                pendingScale[0] = 0.8f + sizeBar.getProgress() / 100f * 0.8f;
                sizeLabel.setText("字体大小  " + Math.round(pendingScale[0] * 100) + "%");
                preview.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(17) * pendingScale[0]);
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        };
        sizeBar.setOnSeekBarChangeListener(listener);
        listener.onProgressChanged(sizeBar, sizeBar.getProgress(), false);

        TextView refreshRow = new TextView(this);
        refreshRow.setText("⟳  立即刷新公休日数据");
        refreshRow.setTextSize(14);
        refreshRow.setGravity(Gravity.CENTER);
        refreshRow.setTextColor(colorAccent);
        refreshRow.setPadding(dp(6), dp(12), dp(6), dp(12));
        GradientDrawable refreshBg = new GradientDrawable();
        refreshBg.setColor(0x14000000);
        refreshBg.setCornerRadius(dp(14));
        refreshBg.setStroke(dp(1), 0x334A6BD6);
        refreshRow.setBackground(refreshBg);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = dp(4);
        refreshRow.setLayoutParams(rlp);
        refreshRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchOnline(true);
            }
        });
        box.addView(refreshRow);

        TextView updateRow = new TextView(this);
        updateRow.setText("检查应用更新（当前 v" + installedVersionName() + "）");
        updateRow.setTextSize(14);
        updateRow.setGravity(Gravity.CENTER);
        updateRow.setTextColor(colorAccent);
        updateRow.setPadding(dp(6), dp(12), dp(6), dp(12));
        GradientDrawable updateBg = new GradientDrawable();
        updateBg.setColor(0x14000000);
        updateBg.setCornerRadius(dp(14));
        updateBg.setStroke(dp(1), 0x334A6BD6);
        updateRow.setBackground(updateBg);
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ulp.topMargin = dp(8);
        updateRow.setLayoutParams(ulp);
        updateRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkUpdate(true);
            }
        });
        updateRow.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showUpdateSourceDialog();
                return true;
            }
        });
        box.addView(updateRow);

        TextView hint = new TextView(this);
        hint.setText(statusBar.getText());
        hint.setTextSize(11);
        hint.setTextColor(0xFF8A93A3);
        hint.setPadding(dp(2), dp(8), dp(2), 0);
        box.addView(hint);

        ScrollView panelScroll = new ScrollView(this);
        panelScroll.addView(box);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("设置")
                .setView(panelScroll)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        themeId = pendingTheme[0];
                        fontScale = pendingScale[0];
                        cardBgOn = cardSwitch.isChecked();
                        gridOn = gridSwitch.isChecked();
                        listLineOn = lineSwitch.isChecked();
                        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                .putInt(PREF_THEME, themeId)
                                .putFloat(PREF_FONT_SCALE, fontScale)
                                .putBoolean(PREF_CARD_BG, cardBgOn)
                                .putBoolean(PREF_GRID, gridOn)
                                .putBoolean(PREF_LIST_LINE, listLineOn).apply();
                        applyPalette();
                        buildUi();
                        refresh();
                    }
                })
                .setNeutralButton("恢复默认", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        themeId = THEME_GLASS;
                        fontScale = 1.0f;
                        cardBgOn = true;
                        gridOn = false;
                        listLineOn = true;
                        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                .putInt(PREF_THEME, themeId)
                                .putFloat(PREF_FONT_SCALE, fontScale)
                                .putBoolean(PREF_CARD_BG, cardBgOn)
                                .putBoolean(PREF_GRID, gridOn)
                                .putBoolean(PREF_LIST_LINE, listLineOn).apply();
                        applyPalette();
                        buildUi();
                        refresh();
                    }
                })
                .setNegativeButton("取消", null)
                .create();
        dlg.show();
    }

    // ---------------- 应用版本在线更新 ----------------

    /** 依次尝试的清单地址：raw 直链 + 时间戳 → CDN + 时间戳 → 原地址 */
    private String[] updateCandidates(String url) {
        String ts = String.valueOf(System.currentTimeMillis());
        String busted = withTs(url, ts);
        String raw = toRawUrl(url);
        // raw.githubusercontent 也有约 5 分钟缓存，同样带时间戳强制取最新
        if (raw != null) return new String[]{withTs(raw, ts), busted, url};
        return new String[]{busted, url};
    }

    /** 给 URL 追加时间戳，绕开 CDN 缓存 */
    private String withTs(String url, String ts) {
        return url + (url.contains("?") ? "&" : "?") + "_=" + ts;
    }

    /** cdn.jsdelivr.net/gh/user/repo@branch/path → raw.githubusercontent.com/user/repo/branch/path */
    private String toRawUrl(String url) {
        String marker = "cdn.jsdelivr.net/gh/";
        int i = url.indexOf(marker);
        if (i < 0) return null;
        String rest = url.substring(i + marker.length());
        int at = rest.indexOf('@');
        int slash = rest.indexOf('/', at < 0 ? 0 : at);
        if (at < 0 || slash < 0) return null;
        String userRepo = rest.substring(0, at);
        String branchAndPath = rest.substring(at + 1);
        int bslash = branchAndPath.indexOf('/');
        if (bslash < 0) return null;
        String branch = branchAndPath.substring(0, bslash);
        String path = branchAndPath.substring(bslash + 1);
        return "https://raw.githubusercontent.com/" + userRepo + "/" + branch + "/" + path;
    }

    private String updateUrl() {
        String raw = getSharedPreferences(PREF, MODE_PRIVATE)
                .getString(PREF_UPDATE_URL, DEFAULT_UPDATE_URL);
        return normalizeUpdateUrl(raw);
    }

    /** 支持三种写法：完整 URL、"owner/repo" 简写、GitHub 网页链接 */
    private String normalizeUpdateUrl(String raw) {
        if (raw == null) return "";
        String t = raw.trim();
        if (t.length() == 0) return "";
        if (t.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+")) {
            return "https://raw.githubusercontent.com/" + t + "/main/update.json";
        }
        if (t.startsWith("github.com/")) {
            t = "https://" + t;
        }
        if (t.contains("github.com") && t.contains("/blob/")) {
            t = t.replace("github.com", "raw.githubusercontent.com").replace("/blob/", "/");
        }
        return t;
    }

    /** 计算 content:// 指向文件的 SHA-256，失败返回 null */
    private static String sha256Of(Context context, Uri uri) {
        InputStream input = null;
        try {
            input = context.getContentResolver().openInputStream(uri);
            if (input == null) return null;
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            int len;
            while ((len = input.read(buffer)) > 0) {
                digest.update(buffer, 0, len);
            }
            StringBuilder sb = new StringBuilder();
            for (byte b : digest.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (input != null) {
                try { input.close(); } catch (Exception ignored) {}
            }
        }
    }

    private int installedVersionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private String installedVersionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** 拉取更新清单，发现更高 versionCode 就提示下载安装 */
    private void checkUpdate(final boolean manual) {
        final String url = updateUrl();
        if (url == null || url.trim().length() == 0 || url.contains("PLACEHOLDER")) {
            if (manual) {
                Toast.makeText(this, "尚未配置更新源地址，长按“检查应用更新”可设置",
                        Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (manual) Toast.makeText(this, "正在检查更新…", Toast.LENGTH_SHORT).show();

        new Thread(new Runnable() {
            @Override
            public void run() {
                // CDN 分支缓存可能会返回旧清单，按“加时间戳 → raw 直链 → 原地址”依次尝试
                String json = null;
                String[] candidates = updateCandidates(url);
                for (String u : candidates) {
                    json = httpGet(u, "application/json,*/*");
                    if (json != null && json.contains("versionCode")) break;
                    json = null;
                }
                final JSONObject obj;
                try {
                    obj = new JSONObject(json == null ? "" : json);
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (manual) Toast.makeText(MainActivity.this,
                                    "检查更新失败，请检查更新源地址", Toast.LENGTH_SHORT).show();
                        }
                    });
                    return;
                }

                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putLong("last_update_check", System.currentTimeMillis()).apply();

                final int newCode = obj.optInt("versionCode", 0);
                final String newName = obj.optString("versionName", "");
                final String apkUrl = obj.optString("apkUrl", "");
                final String notes = obj.optString("notes", "");
                final String sha = obj.optString("sha256", "");

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (newCode > installedVersionCode() && apkUrl.length() > 0) {
                            showUpdateDialog(newName, newCode, apkUrl, notes, sha);
                        } else if (manual) {
                            Toast.makeText(MainActivity.this,
                                    "已是最新版本 v" + installedVersionName(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    private void showUpdateDialog(String newName, int newCode, String apkUrl,
                                  String notes, String sha256) {
        String message = "当前版本 v" + installedVersionName()
                + "\n新版本 v" + newName + "（" + newCode + "）";
        if (notes != null && notes.length() > 0) {
            message += "\n\n更新说明：\n" + notes;
        }
        new AlertDialog.Builder(this)
                .setTitle("发现新版本")
                .setMessage(message)
                .setPositiveButton("下载并安装", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        expectSha256 = sha256;
                        String ts = String.valueOf(System.currentTimeMillis());
                        String direct = toRawUrl(apkUrl);
                        downloadApk(withTs(direct != null ? direct : apkUrl, ts), newName);
                    }
                })
                .setNegativeButton("以后再说", null)
                .show();
    }

    private void downloadApk(String apkUrl, String versionName) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(apkUrl));
            req.setTitle("澳门节假日 v" + versionName);
            req.setDescription("正在下载新版本，完成后会提示安装");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    "澳门节假日-v" + versionName + ".apk");
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm == null) {
                Toast.makeText(this, "系统下载服务不可用", Toast.LENGTH_SHORT).show();
                return;
            }
            downloadId = dm.enqueue(req);
            Toast.makeText(this, "已开始下载，完成后自动提示安装", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "下载失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void installApk(Uri uri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !getPackageManager().canRequestPackageInstalls()) {
            new AlertDialog.Builder(this)
                    .setTitle("需要允许安装应用")
                    .setMessage("系统限制未知来源安装，请允许本应用安装应用后再试")
                    .setPositiveButton("去设置", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                startActivity(new Intent(
                                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                        Uri.parse("package:" + getPackageName())));
                            } catch (Exception ignored) {
                            }
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "无法打开安装界面，请到下载目录手动安装", Toast.LENGTH_LONG).show();
        }
    }

    /** 长按“检查应用更新”时可改更新源 */
    private void showUpdateSourceDialog() {
        final android.widget.EditText input = new android.widget.EditText(this);
        input.setText(getSharedPreferences(PREF, MODE_PRIVATE)
                .getString(PREF_UPDATE_URL, DEFAULT_UPDATE_URL));
        input.setSingleLine(true);
        input.setTextSize(12);
        new AlertDialog.Builder(this)
                .setTitle("更新源地址")
                .setMessage("填 update.json 完整地址，或直接填 用户名/仓库名（自动用 main 分支）；当前 v" + installedVersionName())
                .setView(input)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                .putString(PREF_UPDATE_URL, input.getText().toString().trim())
                                .apply();
                        Toast.makeText(MainActivity.this, "已保存更新源", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 快速跳转：年份 + 月份双滚轮 */
    private void showJumpDialog() {
        int dataMin = 2100;
        int dataMax = 2000;
        for (String key : data().keySet()) {
            int y = Integer.parseInt(key.substring(0, 4));
            if (y < dataMin) dataMin = y;
            if (y > dataMax) dataMax = y;
        }
        int curYear = Calendar.getInstance().get(Calendar.YEAR);
        if (dataMin > dataMax) {
            dataMin = curYear;
            dataMax = curYear + 1;
        }
        int minYear = Math.min(dataMin, curYear - 1);
        // 至少到 2030；有更远的数据或年份推进时自动延伸
        int maxYear = Math.max(Math.max(MAX_BROWSE_YEAR, dataMax + 1), curYear + 2);

        final NumberPicker yearPicker = new NumberPicker(this);
        yearPicker.setMinValue(minYear);
        yearPicker.setMaxValue(maxYear);
        yearPicker.setValue(shown.get(Calendar.YEAR));
        yearPicker.setWrapSelectorWheel(false);
        yearPicker.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        String[] monthLabels = new String[12];
        for (int i = 0; i < 12; i++) monthLabels[i] = (i + 1) + "月";

        final NumberPicker monthPicker = new NumberPicker(this);
        monthPicker.setMinValue(1);
        monthPicker.setMaxValue(12);
        monthPicker.setDisplayedValues(monthLabels);
        monthPicker.setValue(shown.get(Calendar.MONTH) + 1);
        monthPicker.setWrapSelectorWheel(true);
        monthPicker.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(16), dp(12), dp(16), dp(4));
        box.addView(yearPicker);
        box.addView(monthPicker);

        new AlertDialog.Builder(this)
                .setTitle("选择年月（可翻至 " + maxYear + " 年）")
                .setView(box)
                .setPositiveButton("跳转", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shown.set(yearPicker.getValue(), monthPicker.getValue() - 1, 1);
                        refresh();
                    }
                })
                .setNeutralButton("本月", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        shown.setTimeInMillis(System.currentTimeMillis());
                        refresh();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private String fmt(Calendar cal) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
    }

    // ---------------- 数据存取 ----------------

    private void loadLocalData() {
        String cached = readFile(new File(getFilesDir(), CACHE_FILE));
        String builtin = readRaw();
        String use = cached != null && cached.length() > 0 ? cached : builtin;
        dataCache = parseText(use);

        if (cached != null && cached.length() > 0) {
            String meta = readFile(new File(getFilesDir(), META_FILE));
            statusBar.setText("数据：" + (meta == null ? "本地缓存" : meta));
        } else {
            statusBar.setText("数据：内置版本（2024–2027）");
        }
    }

    private String readRaw() {
        try {
            InputStream is = getResources().openRawResource(R.raw.holidays);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private String readFile(File f) {
        if (!f.exists()) return null;
        try {
            FileInputStream fis = new FileInputStream(f);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private void writeFile(File f, String content) {
        try {
            FileOutputStream fos = new FileOutputStream(f);
            fos.write(content.getBytes("UTF-8"));
            fos.close();
        } catch (Exception ignored) {
        }
    }

    private Map<String, Entry> parseText(String text) {
        Map<String, Entry> result = new HashMap<>();
        if (text == null) return result;
        for (String line : text.split("\n")) {
            line = line.trim();
            if (line.length() == 0) continue;
            String[] parts = line.split("\\|", -1);
            if (parts.length < 4) continue;
            if (!parts[0].matches("\\d{4}-\\d{2}-\\d{2}")) continue;
            int kind;
            try {
                kind = Integer.parseInt(parts[2]);
            } catch (Exception e) {
                kind = KIND_HOLIDAY;
            }
            result.put(parts[0], new Entry(parts[1], kind, parts[3]));
        }
        return result;
    }

    private String serialize(Map<String, Entry> map) {
        List<String> keys = new ArrayList<>(map.keySet());
        Collections.sort(keys);
        StringBuilder sb = new StringBuilder();
        for (String k : keys) {
            Entry e = map.get(k);
            sb.append(k).append('|').append(e.name).append('|')
                    .append(e.kind).append('|').append(e.tag).append('\n');
        }
        return sb.toString();
    }

    private Map<String, Entry> parseIcal(String text) {
        Map<String, Entry> result = new HashMap<>();
        if (text == null || text.isEmpty()) return result;

        String normalized = text.replace("\r\n", "\n").replace("\n ", "");
        int idx = 0;
        while (true) {
            int start = normalized.indexOf("BEGIN:VEVENT", idx);
            if (start < 0) break;
            int end = normalized.indexOf("END:VEVENT", start);
            if (end < 0) break;
            String block = normalized.substring(start, end);
            idx = end + 1;

            String date = null;
            String summary = null;
            for (String line : block.split("\n")) {
                if (line.startsWith("DTSTART")) {
                    String value = line.substring(line.indexOf(':') + 1).trim();
                    String digits = value.replaceAll("[^0-9]", "");
                    if (digits.length() >= 8) {
                        date = digits.substring(0, 4) + "-" + digits.substring(4, 6)
                                + "-" + digits.substring(6, 8);
                    }
                } else if (line.startsWith("SUMMARY:")) {
                    summary = line.substring("SUMMARY:".length()).trim();
                }
            }
            if (date == null || summary == null) continue;

            String name = summary;
            String tag = "";
            int kind = KIND_HOLIDAY;

            int cut = summary.indexOf(" (");
            if (cut > 0) name = summary.substring(0, cut).trim();
            if (summary.contains("豁免上班")) {
                kind = KIND_HALF;
                tag = "下午";
            } else if (summary.contains("补假")) {
                tag = "补假";
                if (name.endsWith("的补假")) {
                    name = name.substring(0, name.length() - 3).trim();
                }
            }
            result.put(date, new Entry(name, kind, tag));
        }
        return result;
    }

    private Map<String, Entry> parseYearPage(String html, int year) {
        Map<String, Entry> result = new HashMap<>();
        if (html == null) return result;

        Matcher tableMatcher = TABLE_PAT.matcher(html);
        int tableIndex = 0;
        while (tableMatcher.find()) {
            String table = tableMatcher.group();
            boolean isHalfTable = tableIndex == 1;
            boolean isMakeupTable = tableIndex == 2;

            Matcher rowMatcher = ROW_PAT.matcher(table);
            while (rowMatcher.find()) {
                String row = rowMatcher.group(1);
                List<String> cells = new ArrayList<>();
                Matcher cellMatcher = CELL_PAT.matcher(row);
                while (cellMatcher.find()) {
                    String cell = TAG_PAT.matcher(cellMatcher.group(1)).replaceAll("")
                            .replace("&nbsp;", " ").replace("&amp;", "&").trim();
                    cells.add(cell);
                }
                if (cells.size() < 3) continue;

                String dateCell = null;
                for (String c : cells) {
                    if (DATE_PAT.matcher(c).find()) {
                        dateCell = c;
                        break;
                    }
                }
                if (dateCell == null) continue;

                Matcher dm = DATE_PAT.matcher(dateCell);
                if (!dm.find()) continue;
                int month = Integer.parseInt(dm.group(1));
                int day = Integer.parseInt(dm.group(2));
                boolean afternoon = dm.group(3) != null;

                String name = cells.get(cells.size() - 1);
                name = name.replace("（下午）", "").trim();

                int kind = KIND_HOLIDAY;
                String tag = "";
                if (afternoon || isHalfTable) {
                    kind = KIND_HALF;
                    tag = "下午";
                } else if (isMakeupTable || name.contains("补假")) {
                    tag = "补假";
                    if (name.endsWith("的补假")) {
                        name = name.substring(0, name.length() - 3).trim();
                    }
                }
                String date = String.format(Locale.US, "%04d-%02d-%02d", year, month, day);
                result.put(date, new Entry(name, kind, tag));
            }
            tableIndex++;
        }
        return result;
    }

    // ---------------- 在线更新 --------------

    private String httpGet(String url, String accept) {
        String target = url;
        for (int hop = 0; hop < 4; hop++) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(target).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(18000);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("User-Agent",
                        "Mozilla/5.0 (Linux; Android 14) HolidayCalendar");
                conn.setRequestProperty("Accept", accept);
                conn.setRequestProperty("Accept-Encoding", "identity");
                int code = conn.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    String location = conn.getHeaderField("Location");
                    if (location == null || location.length() == 0) return null;
                    target = location.startsWith("http") ? location
                            : new URL(new URL(target), location).toString();
                    continue;
                }
                if (code != 200) return null;
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append('\n');
                reader.close();
                return sb.toString();
            } catch (Exception e) {
                return null;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        return null;
    }

    private void fetchOnline(boolean manual) {
        if (refreshing) return;
        refreshing = true;
        if (manual) statusBar.setText("正在更新…");

        final boolean isManual = manual;

        new Thread(new Runnable() {
            @Override
            public void run() {
                Map<String, Entry> merged = new HashMap<>();

                int curYear = Calendar.getInstance().get(Calendar.YEAR);
                int pageHits = 0;
                int lastYear = Math.min(MAX_BROWSE_YEAR, curYear + FETCH_AHEAD);
                for (int y = curYear - 3; y <= lastYear; y++) {
                    String html = httpGet(String.format(Locale.US, PAGE_URL, y), "text/html");
                    if (html != null) {
                        Map<String, Entry> part = parseYearPage(html, y);
                        if (!part.isEmpty()) {
                            merged.putAll(part);
                            pageHits++;
                        }
                    }
                }

                String ics = httpGet(ICS_URL, "text/calendar,*/*");
                boolean icsOk = false;
                if (ics != null && ics.contains("BEGIN:VEVENT")) {
                    Map<String, Entry> part = parseIcal(ics);
                    if (!part.isEmpty()) {
                        merged.putAll(part);
                        icsOk = true;
                    }
                }

                final Map<String, Entry> finalData = merged;
                final int finalPageHits = pageHits;
                final boolean finalIcsOk = icsOk;

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        refreshing = false;
                        lastFetchAt = System.currentTimeMillis();
                        if (finalData.isEmpty()) {
                            statusBar.setText("数据：离线版本（更新失败，请检查网络）");
                            if (isManual) Toast.makeText(MainActivity.this,
                                    "更新失败，已使用离线数据", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        dataCache = finalData;
                        writeFile(new File(getFilesDir(), CACHE_FILE), serialize(finalData));

                        int minY = 2100;
                        int maxY = 2000;
                        for (String k : finalData.keySet()) {
                            int y = Integer.parseInt(k.substring(0, 4));
                            if (y < minY) minY = y;
                            if (y > maxY) maxY = y;
                        }
                        String stamp = new SimpleDateFormat("MM-dd HH:mm", Locale.US)
                                .format(new Date());
                        String meta = "官方在线 " + stamp + " · " + minY + "–" + maxY
                                + " 共 " + finalData.size() + " 条";
                        writeFile(new File(getFilesDir(), META_FILE), meta);
                        statusBar.setText("数据：" + meta);

                        refresh();

                        if (isManual) {
                            String extra = "";
                            if (finalPageHits == 0 && !finalIcsOk) extra = "（部分来源未连通）";
                            Toast.makeText(MainActivity.this,
                                    "已更新 " + finalData.size() + " 条数据" + extra,
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }).start();
    }

    // ---------------- 渲染 --------------

    private Map<String, Entry> data() {
        if (dataCache == null) dataCache = new HashMap<>();
        return dataCache;
    }

    private void refresh() {
        monthTitle.setText(shown.get(Calendar.YEAR) + "年" + (shown.get(Calendar.MONTH) + 1) + "月");
        String curPrefix = String.format(Locale.US, "%04d-%02d-",
                shown.get(Calendar.YEAR), shown.get(Calendar.MONTH) + 1);
        if (selectedDate != null && !selectedDate.startsWith(curPrefix)) selectedDate = null;
        if (sectionTitle != null) {
            sectionTitle.setText(selectedDate == null ? "本月公休日" : "当天详情");
        }
        buildGrid();
        buildMonthList();
        autoFetchIfMonthEmpty();
    }

    /** 行高：基础值收紧，并随字号倍率小幅增长，避免大字被裁 */
    private int rowHeight() {
        int base = themeId == THEME_ELEGANT ? 46 : (themeId == THEME_GLASS ? 48 : 42);
        return base + Math.round((fontScale - 1f) * 14f);
    }

    private void buildGrid() {
        boolean elegant = themeId == THEME_ELEGANT;
        boolean glass = themeId == THEME_GLASS;
        int side = dp(elegant ? 12 : (glass ? 12 : 10));
        pageWidthPx = getResources().getDisplayMetrics().widthPixels - side * 2;

        pages.removeAllViews();
        Calendar base = (Calendar) shown.clone();
        for (int d = -1; d <= 1; d++) {
            Calendar m = (Calendar) base.clone();
            m.add(Calendar.MONTH, d);
            LinearLayout page = buildMonthPage(m);
            pages.addView(page, new LinearLayout.LayoutParams(pageWidthPx,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            if (d == 0) grid = page;
        }

        // 高度固定，避免翻页时跳动
        final int pagerHeight = dp(rowHeight()) * 6 + dp(8);
        if (pager.getLayoutParams().height != pagerHeight) {
            pager.getLayoutParams().height = pagerHeight;
            pager.requestLayout();
        }

        // 重建后立刻定位到中间页，并在本帧绘制前再兜底一次，避免闪出左页
        final int center = pageWidthPx;
        pager.scrollTo(center, 0);
        pager.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                pager.scrollTo(center, 0);
                pager.getViewTreeObserver().removeOnPreDrawListener(this);
                return true;
            }
        });
    }

    /** 翻页容器：禁用惯性滑动，松手即停，便于立刻吸附到整页 */
    private static class SnapPager extends HorizontalScrollView {
        SnapPager(Context c) {
            super(c);
        }

        @Override
        public void fling(int velocityX) {
            // 不惯性滑动，松手后交给 snapToNearestPage 立即收尾
        }
    }

    /** 生成某个月的一页（6 行 × 7 列，周一为第一列） */
    private LinearLayout buildMonthPage(Calendar monthCal) {
        boolean elegant = themeId == THEME_ELEGANT;
        boolean glass = themeId == THEME_GLASS;
        Map<String, Entry> data = data();

        int year = monthCal.get(Calendar.YEAR);
        int month = monthCal.get(Calendar.MONTH);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(6), 0, dp(6), 0);

        Calendar first = Calendar.getInstance();
        first.set(year, month, 1);
        int offset = (first.get(Calendar.DAY_OF_WEEK) + 5) % 7;

        Calendar cursor = (Calendar) first.clone();
        cursor.add(Calendar.DAY_OF_MONTH, -offset);

        for (int row = 0; row < 6; row++) {
            LinearLayout rowLayout = new LinearLayout(this);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            rowLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(rowHeight())));

            for (int col = 0; col < 7; col++) {
                FrameLayout cell = new FrameLayout(this);
                LinearLayout.LayoutParams cellLp = new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.MATCH_PARENT, 1);
                if (elegant) cellLp.setMargins(dp(1), dp(1), dp(1), dp(1));
                cell.setLayoutParams(cellLp);

                LinearLayout cellInner = new LinearLayout(this);
                cellInner.setOrientation(LinearLayout.VERTICAL);
                cellInner.setGravity(Gravity.CENTER);
                cellInner.setLayoutParams(new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

                final String dateStr = fmt(cursor);
                boolean inMonth = cursor.get(Calendar.MONTH) == month;
                int dayOfWeek = cursor.get(Calendar.DAY_OF_WEEK);
                boolean weekend = dayOfWeek == Calendar.SATURDAY
                        || dayOfWeek == Calendar.SUNDAY;
                Entry entry = data.get(dateStr);

                TextView day = new TextView(this);
                day.setText(String.valueOf(cursor.get(Calendar.DAY_OF_MONTH)));
                day.setTextSize(elegant ? 15 : (glass ? 15 : 14));
                day.setGravity(Gravity.CENTER);

                boolean isAl = inMonth && alDates.contains(dateStr);
                int color;
                if (!inMonth) {
                    color = colorEmpty;
                } else if (isAl) {
                    color = colorHoliday;
                } else if (entry != null && entry.kind == KIND_HALF) {
                    color = colorHalf;
                } else if (entry != null) {
                    color = colorHoliday;
                } else if (weekend) {
                    color = colorWeekend;
                } else {
                    color = colorNormal;
                }
                day.setTextColor(color);
                if (glass && dateStr.equals(todayStr)) {
                    day.setTextColor(0xFFFFFFFF);
                    day.setTypeface(Typeface.DEFAULT_BOLD);
                }
                if (elegant && inMonth && entry != null) {
                    day.setTypeface(Typeface.DEFAULT_BOLD);
                }

                TextView note = new TextView(this);
                String noteText = "";
                boolean isHolidayNote = entry != null && inMonth;
                if (isAl) {
                    noteText = "AL";
                } else if (isHolidayNote) {
                    // 节假日优先：优先显示节假日名称
                    noteText = entry.tag.length() > 0 ? entry.name + entry.tag : entry.name;
                } else if (inMonth) {
                    // 没有节假日才显示农历
                    noteText = lunarLabel(cursor);
                }
                note.setText(noteText);
                note.setTextSize(elegant ? 9 : 8);
                int noteColor;
                if (isAl) {
                    noteColor = glass && dateStr.equals(todayStr) ? 0xDFFFFFFF : colorHoliday;
                } else if (isHolidayNote) {
                    noteColor = glass && dateStr.equals(todayStr)
                            ? 0xDFFFFFFF
                            : (entry.kind == KIND_HALF ? colorHalf : colorHoliday);
                } else {
                    noteColor = glass && dateStr.equals(todayStr)
                            ? 0xCCFFFFFF
                            : (glass ? 0xFF8E9AB0 : (elegant ? 0xFF9AA3B2 : 0xFF999999));
                }
                note.setTextColor(noteColor);
                note.setGravity(Gravity.CENTER);
                note.setMaxLines(2);

                cellInner.addView(day);
                cellInner.addView(note);
                cell.addView(cellInner);

                // 公休日右上角的小「休」标
                if (inMonth && entry != null && entry.kind == KIND_HOLIDAY) {
                    TextView badge = new TextView(this);
                    badge.setText("休");
                    badge.setTextSize(7);
                    badge.setTypeface(Typeface.DEFAULT_BOLD);
                    badge.setTextColor(0xFFFFFFFF);
                    badge.setGravity(Gravity.CENTER);
                    GradientDrawable badgeBg = new GradientDrawable();
                    badgeBg.setColor(colorHoliday);
                    badgeBg.setCornerRadius(dp(3));
                    badge.setBackground(badgeBg);
                    badge.setPadding(dp(2), 0, dp(2), dp(1));
                    FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    badgeLp.gravity = Gravity.TOP | Gravity.END;
                    badgeLp.topMargin = dp(2);
                    badgeLp.rightMargin = dp(3);
                    badge.setLayoutParams(badgeLp);
                    cell.addView(badge);
                }

                // AL 标记：右上角的小「休」标（那天已经是公休日就不重复画）
                if (isAl && !(entry != null && entry.kind == KIND_HOLIDAY)) {
                    TextView alBadge = new TextView(this);
                    alBadge.setText("休");
                    alBadge.setTextSize(7);
                    alBadge.setTypeface(Typeface.DEFAULT_BOLD);
                    alBadge.setTextColor(0xFFFFFFFF);
                    alBadge.setGravity(Gravity.CENTER);
                    GradientDrawable alBg = new GradientDrawable();
                    alBg.setColor(colorHoliday);
                    alBg.setCornerRadius(dp(3));
                    alBadge.setBackground(alBg);
                    alBadge.setPadding(dp(2), 0, dp(2), dp(1));
                    FrameLayout.LayoutParams alLp = new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT);
                    alLp.gravity = Gravity.TOP | Gravity.END;
                    alLp.topMargin = dp(2);
                    alLp.rightMargin = dp(3);
                    alBadge.setLayoutParams(alLp);
                    cell.addView(alBadge);
                }

                // 日期方框（可在设置里关掉）
                if (gridOn && inMonth) {
                    GradientDrawable cellBox = new GradientDrawable();
                    cellBox.setColor(0x00000000);
                    cellBox.setCornerRadius(dp(8));
                    cellBox.setStroke(dp(1), glass ? 0x334A6BD6 : 0x22000000);
                    cell.setBackground(cellBox);
                }

                if (dateStr.equals(todayStr)) {
                    if (glass) {
                        cell.setBackground(todayGradient());
                    } else if (elegant) {
                        cell.setBackground(rounded(colorTodayBg, 12));
                    } else {
                        cell.setBackgroundColor(colorTodayBg);
                    }
                }

                // 选中日期高亮（盖在今日高亮上面，优先级最高）
                if (inMonth && dateStr.equals(selectedDate)) {
                    GradientDrawable hl = new GradientDrawable();
                    hl.setColor(0x1F3A6CF6);
                    hl.setCornerRadius(dp(8));
                    hl.setStroke(dp(1.5f), 0xFF5B7BF7);
                    cell.setBackground(hl);
                }

                final boolean sameMonthCell = inMonth;
                cell.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!sameMonthCell) {
                            shown.set(Integer.parseInt(dateStr.substring(0, 4)),
                                    Integer.parseInt(dateStr.substring(5, 7)) - 1, 1);
                            refresh();
                        } else {
                            selectedDate = dateStr.equals(selectedDate) ? null : dateStr;
                            refresh();
                        }
                    }
                });

                rowLayout.addView(cell);
                cursor.add(Calendar.DAY_OF_MONTH, 1);
            }
            page.addView(rowLayout);
        }
        return page;
    }

    /** 只显示点选那一天的详情；不是公休日则给出 AL 选项 */
    private void buildSelectedDay(String date, Map<String, Entry> data,
                                  boolean elegant, int month) {
        Entry entry = data.get(date);
        boolean marked = alDates.contains(date);
        int day = Integer.parseInt(date.substring(8, 10));
        Calendar cal = Calendar.getInstance();
        cal.set(Integer.parseInt(date.substring(0, 4)), month, day);
        String week = "星期" + WEEK_LABELS[cal.get(Calendar.DAY_OF_WEEK) - 1];

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(12), dp(8), dp(12));

        TextView dateView = new TextView(this);
        dateView.setText((month + 1) + "月" + day + "日");
        dateView.setTextSize(13);
        dateView.setTypeface(Typeface.DEFAULT_BOLD);
        dateView.setTextColor(entry != null || marked ? colorHoliday : colorNormal);
        dateView.setLayoutParams(new LinearLayout.LayoutParams(dp(66),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView weekView = new TextView(this);
        weekView.setText(week);
        weekView.setTextSize(12);
        weekView.setTextColor(elegant ? 0xFF8A93A3 : 0xFF777777);
        weekView.setLayoutParams(new LinearLayout.LayoutParams(dp(58),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView nameView = new TextView(this);
        String label;
        if (entry != null) {
            label = entry.tag.length() > 0
                    ? entry.name + "（" + entry.tag + "）" : entry.name;
        } else if (marked) {
            label = "AL（自定义）";
        } else {
            label = "无公众假期";
        }
        nameView.setText(label);
        nameView.setTextSize(13);
        nameView.setTextColor(entry != null || marked ? colorHoliday : colorNormal);
        nameView.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        row.addView(dateView);
        row.addView(weekView);
        row.addView(nameView);

        // 不是公休日：右侧给一个 AL 操作
        if (entry == null) {
            TextView act = new TextView(this);
            act.setText(marked ? "取消 AL" : "标记 AL");
            act.setTextSize(12);
            act.setTypeface(Typeface.DEFAULT_BOLD);
            act.setTextColor(marked ? 0xFF8A93A3 : colorHoliday);
            act.setPadding(dp(10), dp(5), dp(10), dp(5));
            GradientDrawable actBg = new GradientDrawable();
            actBg.setColor(marked ? 0x11FFFFFF : 0x14E2483D);
            actBg.setCornerRadius(dp(10));
            actBg.setStroke(dp(1), marked ? 0x332A3550 : 0x33E2483D);
            act.setBackground(actBg);
            act.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    toggleAl(selectedDate);
                }
            });
            LinearLayout.LayoutParams actLp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            actLp.leftMargin = dp(6);
            act.setLayoutParams(actLp);
            row.addView(act);
        }

        monthList.addView(row);

        // 返回整月
        TextView back = new TextView(this);
        back.setText("← 显示本月全部公休日");
        back.setTextSize(12);
        back.setTextColor(elegant ? 0xFF8A93A3 : 0xFF6B7788);
        back.setPadding(dp(8), dp(10), dp(8), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedDate = null;
                refresh();
            }
        });
        monthList.addView(back);
    }

    private void toggleAl(String date) {
        if (date == null) return;
        if (alDates.contains(date)) alDates.remove(date);
        else alDates.add(date);
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putStringSet(PREF_AL, new java.util.HashSet<>(alDates)).apply();
        refresh();
    }

    /** 取某天的农历文字：初一显示月份名，其余显示日名（用本地农历表，不依赖 ICU） */
    private String lunarLabel(Calendar cal) {
        return LunarUtil.shortLabel(cal);
    }


    private void buildMonthList() {
        monthList.removeAllViews();
        Map<String, Entry> data = data();
        boolean elegant = themeId == THEME_ELEGANT;

        int year = shown.get(Calendar.YEAR);
        int month = shown.get(Calendar.MONTH);
        String prefix = String.format(Locale.US, "%04d-%02d-", year, month + 1);

        if (selectedDate != null && selectedDate.startsWith(prefix)) {
            buildSelectedDay(selectedDate, data, elegant, month);
            return;
        }

        List<String> dates = new ArrayList<>();
        for (String key : data.keySet()) {
            if (key.startsWith(prefix)) dates.add(key);
        }
        Collections.sort(dates);

        if (dates.isEmpty()) {
            TextView empty = new TextView(this);
            String yearPrefix = String.format(Locale.US, "%04d-", year);
            boolean yearKnown = false;
            for (String key : data.keySet()) {
                if (key.startsWith(yearPrefix)) {
                    yearKnown = true;
                    break;
                }
            }
            // 整年都有数据 → 这个月就是真的没有假期；整年都没有才是“官方未公布”
            empty.setText(yearKnown
                    ? "本月无公众假期"
                    : "本月无公休数据（官方未公布，可在设置里刷新）");
            empty.setTextSize(13);
            empty.setTextColor(elegant ? 0xFF8A93A3 : 0xFF888888);
            empty.setPadding(dp(8), dp(8), dp(2), dp(8));
            monthList.addView(empty);
            return;
        }

        for (String date : dates) {
            Entry entry = data.get(date);
            int day = Integer.parseInt(date.substring(8, 10));
            Calendar cal = Calendar.getInstance();
            cal.set(year, month, day);
            String week = "星期" + WEEK_LABELS[cal.get(Calendar.DAY_OF_WEEK) - 1];

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(9), dp(8), dp(9));

            TextView dateView = new TextView(this);
            dateView.setText((month + 1) + "月" + day + "日");
            dateView.setTextSize(13);
            dateView.setTypeface(Typeface.DEFAULT_BOLD);
            dateView.setTextColor(entry.kind == KIND_HALF ? colorHalf : colorHoliday);
            dateView.setLayoutParams(new LinearLayout.LayoutParams(dp(66),
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView weekView = new TextView(this);
            weekView.setText(week);
            weekView.setTextSize(12);
            weekView.setTextColor(elegant ? 0xFF8A93A3 : 0xFF777777);
            weekView.setLayoutParams(new LinearLayout.LayoutParams(dp(58),
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView nameView = new TextView(this);
            String label = entry.tag.length() > 0
                    ? entry.name + "（" + entry.tag + "）" : entry.name;
            nameView.setText(label);
            nameView.setTextSize(13);
            nameView.setTextColor(colorNormal);
            nameView.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1));

            row.addView(dateView);
            row.addView(weekView);
            row.addView(nameView);
            monthList.addView(row);

            if (listLineOn) {
                View divider = new View(this);
                divider.setBackgroundColor(themeId == THEME_GLASS ? 0x1A2A3550 : 0xFFEDF1F7);
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                vp.setMargins(dp(8), 0, dp(8), 0);
                divider.setLayoutParams(vp);
                monthList.addView(divider);
            }
        }
    }
}
