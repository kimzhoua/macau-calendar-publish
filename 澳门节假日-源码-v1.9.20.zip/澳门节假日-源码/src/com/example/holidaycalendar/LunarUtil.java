package com.example.holidaycalendar;

import java.util.Calendar;

/**
 * 农历换算（1900-01-31 起，覆盖 1900–2099）。
 * 使用通行的农历年数据表，和官方万年历一致；不使用 android.icu 的推算结果
 * （icu 的天文近似在某些年份会差一天，例如 2027 年春节）。
 */
public final class LunarUtil {

    /** 每年一个 16 位以上数据：低 4 位＝闰月月份(0 无闰月)；bit(16-month)＝该月是否 30 天；bit16＝闰月是否 30 天 */
    private static final int[] YEAR_INFO = {
            0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0,
            0x09ad0, 0x055d2, 0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540,
            0x0d6a0, 0x0ada2, 0x095b0, 0x14977, 0x04970, 0x0a4b0, 0x0b4b5, 0x06a50,
            0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970, 0x06566, 0x0d4a0,
            0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
            0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2,
            0x0a950, 0x0b557, 0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5d0, 0x14573,
            0x052b0, 0x0a9a8, 0x0e950, 0x06aa0, 0x0aea6, 0x0ab50, 0x04b60, 0x0aae4,
            0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0, 0x096d0, 0x04dd5,
            0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b5a0, 0x195a6,
            0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46,
            0x0ab60, 0x09570, 0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58,
            0x05ac0, 0x0ab60, 0x096d5, 0x092e0, 0x0c960, 0x0d954, 0x0d4a0, 0x0da50,
            0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5, 0x0a950, 0x0b4a0,
            0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
            0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260,
            0x0ea65, 0x0d530, 0x05aa0, 0x076a3, 0x096d0, 0x04afb, 0x04ad0, 0x0a4d0,
            0x1d0b6, 0x0d250, 0x0d520, 0x0dd45, 0x0b5a0, 0x056d0, 0x055b2, 0x049b0,
            0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0, 0x14b63, 0x09370,
            0x049f8, 0x04970, 0x064b0, 0x168a6, 0x0ea50, 0x06aa0, 0x1a6c4, 0x0aae0,
            0x092e0, 0x0d2e3, 0x0c960, 0x0d557, 0x0d4a0, 0x0da50, 0x05d55, 0x056a0,
            0x0a6d0, 0x055d4, 0x052d0, 0x0a9b8, 0x0a950, 0x0b4a0, 0x0b6a6, 0x0ad50,
            0x055a0, 0x0aba4, 0x0a5b0, 0x052b0, 0x0b273, 0x06930, 0x07337, 0x06aa0,
            0x0ad50, 0x14b55, 0x04b60, 0x0a570, 0x054e4, 0x0d160, 0x0e968, 0x0d520,
            0x0daa0, 0x16aa6, 0x056d0, 0x04ae0, 0x0a9d4, 0x0a2d0, 0x0d150, 0x0f252,
    };

    private static final int[] YEAR_DAYS = new int[YEAR_INFO.length];

    private static final String[] DAY_NAMES = {"初一", "初二", "初三", "初四", "初五", "初六",
            "初七", "初八", "初九", "初十", "十一", "十二", "十三", "十四", "十五", "十六",
            "十七", "十八", "十九", "二十", "廿一", "廿二", "廿三", "廿四", "廿五", "廿六",
            "廿七", "廿八", "廿九", "三十"};

    private static final String[] MONTH_NAMES = {"正月", "二月", "三月", "四月", "五月", "六月",
            "七月", "八月", "九月", "十月", "冬月", "腊月"};

    static {
        for (int i = 0; i < YEAR_INFO.length; i++) YEAR_DAYS[i] = daysOfYear(YEAR_INFO[i]);
    }

    private LunarUtil() {
    }

    private static int daysOfMonth(int yearInfo, int month) {
        return ((yearInfo >> (16 - month)) & 1) == 1 ? 30 : 29;
    }

    private static int leapMonth(int yearInfo) {
        return yearInfo & 0xf;
    }

    private static int daysOfLeapMonth(int yearInfo) {
        if (leapMonth(yearInfo) == 0) return 0;
        return ((yearInfo >> 16) & 1) == 1 ? 30 : 29;
    }

    private static int daysOfYear(int yearInfo) {
        int sum = 0;
        for (int m = 1; m <= 12; m++) sum += daysOfMonth(yearInfo, m);
        return sum + daysOfLeapMonth(yearInfo);
    }

    /** 距 1900-01-31 的天数（按自然日算，不受时区偏移影响） */
    private static long dayOffset(Calendar cal) {
        Calendar base = Calendar.getInstance();
        base.clear();
        base.set(1900, Calendar.JANUARY, 31);
        Calendar d = Calendar.getInstance();
        d.clear();
        d.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        long diff = d.getTimeInMillis() - base.getTimeInMillis();
        // 用本地零点差值四舍五入到整天，避免夏令时/时区造成的几小时误差
        return Math.round(diff / 86400000.0);
    }

    /** 返回农历信息：{月, 日, 是否闰月}；超出 1900–2099 返回 null */
    public static int[] lunarOf(Calendar cal) {
        long offset = dayOffset(cal);
        if (offset < 0) return null;
        int idx = 0;
        while (idx < YEAR_DAYS.length && offset >= YEAR_DAYS[idx]) {
            offset -= YEAR_DAYS[idx];
            idx++;
        }
        if (idx >= YEAR_DAYS.length) return null;
        int yearInfo = YEAR_INFO[idx];
        int leap = leapMonth(yearInfo);

        int month = 1;
        int isLeap = 0;
        while (true) {
            int len = daysOfMonth(yearInfo, month);
            if (offset < len) break;
            offset -= len;
            if (month == leap) {
                len = daysOfLeapMonth(yearInfo);
                if (offset < len) {
                    isLeap = 1;
                    break;
                }
                offset -= len;
            }
            month++;
            if (month > 12) return null;
        }
        return new int[]{month, (int) offset + 1, isLeap};
    }

    /** 日期下方的农历短标签：初一显示月名（闰月带「闰」），其余显示日名 */
    public static String shortLabel(Calendar cal) {
        try {
            int[] info = lunarOf(cal);
            if (info == null) return "";
            int month = info[0], day = info[1];
            boolean leap = info[2] == 1;
            if (day == 1) return (leap ? "闰" : "") + MONTH_NAMES[month - 1];
            return DAY_NAMES[day - 1];
        } catch (Throwable t) {
            return "";
        }
    }
}
