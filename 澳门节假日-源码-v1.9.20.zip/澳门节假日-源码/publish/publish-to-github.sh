#!/bin/bash
# 把 update.json 和 APK 一键发布到你的 GitHub 仓库（覆盖同名文件，地址永久不变）
#
# 用法：
#   export GH_TOKEN=ghp_xxx          # 你的 GitHub token（Fine-grained，勾选 Contents: Read and write）
#   ./publish-to-github.sh <用户名>/<仓库名> <APK路径> [版本号] [版本名] [更新说明]
#
# 例：
#   export GH_TOKEN=ghp_xxx
#   ./publish-to-github.sh openxplay/holiday-mo ../澳门节假日-v1.8.0.apk 27 1.8.0 "新增××功能"
#
# 仓库里的固定文件：
#   update.json        -> https://raw.githubusercontent.com/<用户名>/<仓库名>/main/update.json
#   app-latest.apk     -> https://raw.githubusercontent.com/<用户名>/<仓库名>/main/app-latest.apk
# 只要仓库和分支不变，这两个地址永远不变，App 里配置一次即可长期自动发现新版本。

set -euo pipefail

REPO="${1:?用法: publish-to-github.sh <用户名>/<仓库名> <APK路径> [版本号] [版本名] [说明]}"
APK="${2:?缺少 APK 路径}"
VCODE="${3:-$(sed -n 's/.*android:versionCode="\([0-9]*\)".*/\1/p' "$(dirname "$0")/../AndroidManifest.xml")}"
VNAME="${4:-$(sed -n 's/.*android:versionName="\([0-9.]*\)".*/\1/p' "$(dirname "$0")/../AndroidManifest.xml")}"
NOTES="${5:-本次更新}"
BRANCH="${BRANCH:-main}"

if [ -z "${GH_TOKEN:-}" ]; then
  echo "错误：请先 export GH_TOKEN=<你的 GitHub token>（Fine-grained token，权限 Contents: Read and write）"
  exit 1
fi

API="https://api.github.com/repos/$REPO/contents"
RAW="https://raw.githubusercontent.com/$REPO/$BRANCH"

put_file() { # $1=仓库内文件名 $2=本地文件
  local name="$1" src="$2"
  local b64
  b64=$(base64 -w0 "$src")
  local sha
  sha=$(curl -s -m 20 -H "Authorization: token $GH_TOKEN" "$API/$name" \
        | sed -n 's/.*"sha": *"\([a-f0-9]*\)".*/\1/p' | head -1)

  local payload="/tmp/gh_payload.json"
  if [ -n "$sha" ]; then
    printf '{"message":"publish %s","branch":"%s","sha":"%s","content":"%s"}' \
      "$name" "$BRANCH" "$sha" "$b64" > "$payload"
  else
    printf '{"message":"publish %s","branch":"%s","content":"%s"}' \
      "$name" "$BRANCH" "$b64" > "$payload"
  fi

  local code
  code=$(curl -s -o /tmp/gh_resp.json -w '%{http_code}' -m 60 \
    -X PUT -H "Authorization: token $GH_TOKEN" \
    -H "Accept: application/vnd.github+json" \
    --data @"$payload" "$API/$name")

  if [ "$code" = "200" ] || [ "$code" = "201" ]; then
    echo "  ✓ $name 已更新"
  else
    echo "  ✗ $name 上传失败（HTTP $code）："
    head -c 400 /tmp/gh_resp.json
    echo
    exit 1
  fi
}

echo "→ 发布 v$VNAME ($VCODE) 到 $REPO:$BRANCH"

# 1) 先传 APK，固定命名为 app-latest.apk
put_file "app-latest.apk" "$APK"

# 2) 再生成并传 update.json（带 SHA-256，App 下载后会校验安装包）
SHA=$(sha256sum "$APK" | awk '{print $1}')
cat > /tmp/update.json <<EOF
{
  "versionCode": $VCODE,
  "versionName": "$VNAME",
  "apkUrl": "$RAW/app-latest.apk",
  "sha256": "$SHA",
  "notes": "$NOTES"
}
EOF
put_file "update.json" /tmp/update.json

echo
echo "完成。App 里填这个地址即可长期自动更新："
echo "  $RAW/update.json"
echo "（或填简写：$REPO）"
