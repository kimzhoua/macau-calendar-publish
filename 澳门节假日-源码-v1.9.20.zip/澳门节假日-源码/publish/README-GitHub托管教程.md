# 把自己仓库做成「应用更新源」的 3 步教程

目标：让已经装在手机上的旧版本 App，能自动发现你发布的新版本。
思路：把 `update.json`（版本清单）和 APK 放在一个**公开的 GitHub 仓库**里，
App 从 `raw.githubusercontent.com` 的固定地址读清单。

## 步骤

1. **建仓库**（例如 `holiday-mo`，公开 Public、勾选 Add README）。
2. **上传两个文件到仓库根目录**：
   - `update.json`（本目录里的模板，改 `versionCode` / `versionName` / `apkUrl` / `notes`）
   - `澳门节假日-vX.X.X.apk`（新版安装包）
3. **拿到 APK 的固定直链**，填进 `update.json` 的 `apkUrl`：

   ```
   https://raw.githubusercontent.com/<用户名>/<仓库名>/main/<APK文件名>
   ```

   注意：文件名含中文时建议改名为 `app-latest.apk` 这类纯英文名，链接更稳。
   每次发新版，覆盖同名 APK 和同名 `update.json`，链接就**不用变**。

4. **让 App 用这个清单**，二选一：
   - 让我把 `DEFAULT_UPDATE_URL` 改成上面的 raw 地址，重新打包（推荐，装一次就永久自动）
   - 或临时：设置面板长按「检查应用更新」→ 直接填 `用户名/仓库名`
     （App 会自动拼成 `https://raw.githubusercontent.com/用户名/仓库名/main/update.json`）

## update.json 字段

```json
{
  "versionCode": 23,            // 必须比手机上装的大才会提示更新
  "versionName": "1.7.6",
  "apkUrl": "https://raw.githubusercontent.com/<你>/<仓库>/main/app-latest.apk",
  "notes": "更新说明，可用 \n 换行"
}
```

## 注意事项

- 仓库必须 **Public**，否则 raw 链接 404。
- `raw.githubusercontent.com` 对单个文件有大小限制（APK 几十 KB 完全没问题）。
- 本 App 的 debug 签名证书是固定的（见 `debug.keystore`），所以新版可直接覆盖安装；
  如果你换电脑重新生成证书，用户必须先卸载。
